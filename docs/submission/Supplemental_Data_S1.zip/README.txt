Supplemental Data S1
Curated inputs and stored analysis outputs for the extracytoplasmic charge study.
See DATA_AVAILABILITY.md for excluded third-party raw inputs, retrieval instructions and manual curation limits.
Analysis code and reproducibility commands: https://github.com/ajayvellanki0720-boop/acidophile-ph-limits-submission
This file is intended for direct upload as journal-hosted supplemental data, without an external DOI.
